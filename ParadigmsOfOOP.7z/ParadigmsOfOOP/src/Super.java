public class Super {
    private String str = new String();
    public Super(String str){
        this.str = str;
    }
    public String getText(){
        return str;
    }
}
