public class USB extends Super {
    public USB(String str){
        super(str);
    }
    public void writeUSB(){
        System.out.println("Your text '" + getText() + "' is located in USB.");
    }
}
